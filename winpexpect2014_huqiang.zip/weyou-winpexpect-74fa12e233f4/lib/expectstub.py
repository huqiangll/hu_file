import sys, winpexpect;
winpexpect._stub(*sys.argv[1:])
